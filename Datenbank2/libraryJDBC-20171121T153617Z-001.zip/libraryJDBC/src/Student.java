public class Student {
    private int id;
    private int group_id;
    private String name;

    public Student(int id, int group_id, String name) {
        this.id = id;
        this.group_id = group_id;
        this.name = name ;
    }

    public String getName() {
        return name;
    }

    public int getGroup_id() {
        return group_id;
    }

    @Override
    public String toString() {
        return name;
    }
}

