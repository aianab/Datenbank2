import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JDBCConnector {
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/bibliothek?autoReconnect=true&useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "uhyhuqape";

    ArrayList<Group> groupsArrayList = new ArrayList<>();
    ArrayList<Student> studentArrayList = new ArrayList<>();

    public void executeDataFromGroup() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
            Statement statement = connection.createStatement();
            ResultSet rsGroup = statement.executeQuery("SELECT * FROM groups");

            while (rsGroup.next()) {
                Group group = new Group(rsGroup.getInt("Id"),
                        rsGroup.getString("Name"));
                groupsArrayList.add(group);
            }
        } catch (ClassNotFoundException e) {e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void executeDataFromStudent() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
            Statement studentStatement = connection.createStatement();
            ResultSet rsStudent = studentStatement.executeQuery("SELECT * FROM student");

            while (rsStudent.next()) {
                for (Group group : groupsArrayList) {
                    if (group.getId() == rsStudent.getInt("group_Id")) {
                        Student student = new Student(rsStudent.getInt("Id"),
                                rsStudent.getInt("group_Id"),
                                rsStudent.getString("Name"));
                        group.addStudent(student);
                        Student student1 = new Student(rsStudent.getInt("Id"),
                                rsStudent.getInt("group_Id"),
                                rsStudent.getString("Name"));
                        studentArrayList.add(student1);
                    }
                }
            }
        } catch (ClassNotFoundException e) {e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void manyToManyBookAuthor() {
        String query = "SELECT Author.name, Book.name FROM BookAuthor JOIN Author ON BookAuthor.author_id = Author.id JOIN Book ON BookAuthor.book_id = Book.id";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);
            System.out.println("");
            System.out.println("                 Автор - Книга");
            while (rs.next()) {
                BookAuthor bookAuthor = new BookAuthor();
                bookAuthor.setAuthorName(rs.getString("Author.name"));
                bookAuthor.setBookName(rs.getString("Book.name"));
                System.out.println(String.format("%-20s   -   %s", bookAuthor.getAuthorName(), bookAuthor.getBookName()));
            }
        } catch (SQLException ex) {
            Logger lgr = Logger.getLogger(JDBCConnector.class.getName());
            lgr.log(Level.SEVERE, ex.getMessage(), ex);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    void printDataFromGroups() {
        System.out.println("");
        System.out.println("        Groups");
        for (Group group : groupsArrayList) {
            System.out.println(group.getName() + " " + group.getStudentArrayList());
            System.out.println("");
        }
    }

    void printDataFromStudent() {
        System.out.println("        Student");
        for (Student student : studentArrayList) {
            for (Group group : groupsArrayList) {
                if (group.getId() == student.getGroup_id()) {
                    System.out.println("Student: " + student.getName());
                    System.out.println("Group: " + group.getName());
                    System.out.println("");
                }
            }
        }
    }
}