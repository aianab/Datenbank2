public class start {
    public static void main(String[] args) {
        JDBCConnector jdbcConnector = new JDBCConnector();
        jdbcConnector.executeDataFromGroup();
        jdbcConnector.executeDataFromStudent();
        jdbcConnector.printDataFromStudent();
        jdbcConnector.printDataFromGroups();
        jdbcConnector.manyToManyBookAuthor();
    }
}
