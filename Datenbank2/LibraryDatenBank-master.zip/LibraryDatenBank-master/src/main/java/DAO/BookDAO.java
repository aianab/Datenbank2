package DAO;

import Entity.Author;
import Entity.Book;

import java.sql.SQLException;
import java.util.Collection;

public interface BookDAO {
    public void addBook(Book book) throws SQLException, Exception;

}

