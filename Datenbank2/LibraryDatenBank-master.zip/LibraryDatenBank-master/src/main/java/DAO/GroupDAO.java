package DAO;


import Entity.Group;

import java.sql.SQLException;

public interface GroupDAO {
    public void addGroup(Group group) throws SQLException, Exception;
}
