package DAO;

import Entity.Student;

import java.sql.SQLException;

public interface StudentDAO {
    public void addStudent(Student student) throws SQLException, Exception;
}
