
import Entity.Author;
import Entity.Book;
import Entity.Group;
import Entity.Student;
import Util.HibernateUtil;
import org.hibernate.Session;

import java.sql.SQLException;
import java.util.ArrayList;

public class App {


public static void main(String[] args) {




        Book book1 = new Book("Финансист");
        Book book2 = new Book("Стоик");
        Book book3 = new Book("Титан");

        Author author = new Author("Теодор Драйзер");

        ArrayList<Book> books = new ArrayList<Book>();

        books.add(book1);
        books.add(book2);
        books.add(book3);

        author.setBooks(books);


        Student student1 = new Student("Atay Nasybek uulu");
        Student student2 = new Student("Baktiyar Tentimischov");
        Student student3 = new Student("Ayana Baytakova");

        ArrayList<Student> students = new ArrayList<Student>();
        students.add(student1);
        students.add(student2);
        students.add(student3);

        Group group = new Group("IG-1-15");

        group.setStudentSet(students);

        Session session= HibernateUtil.openSession();
        session.beginTransaction();
        session.save(author);
        session.getTransaction().commit();
        session.close();

    }

}

